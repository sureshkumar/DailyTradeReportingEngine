package com.morgan.report.utility;



import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Currency;
import java.util.HashSet;
import java.util.Set;

import com.morgan.report.domain.Instruction;
import com.morgan.report.domain.InstructionDetails;
import com.morgan.report.domain.TradeAction;

public class FakeInstructionsGenerator {
    public static Set<Instruction> getFakeInstructions() {
        return new HashSet<>(Arrays.asList(

            new Instruction(
                "foo",
                TradeAction.BUY,
                LocalDate.of(2016, 1, 1),
                LocalDate.of(2016, 1, 2),
                new InstructionDetails(
                        Currency.getInstance("SGD"),
                        BigDecimal.valueOf(0.50),
                        200,
                        BigDecimal.valueOf(100.25))),

            new Instruction(
                "bar",
                TradeAction.BUY,
                LocalDate.of(2016, 1, 5),
                LocalDate.of(2016, 1, 7),
                new InstructionDetails(
                        Currency.getInstance("AED"),
                        BigDecimal.valueOf(0.22),
                        450,
                        BigDecimal.valueOf(150.5)))));
    }
}
