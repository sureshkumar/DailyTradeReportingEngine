package com.morgan.report;
import java.util.Set;

import com.morgan.report.domain.IReportGenerator;
import com.morgan.report.domain.Instruction;
import com.morgan.report.domain.ReportGenerator;
import com.morgan.report.utility.FakeInstructionsGenerator;

public class Main {

    public static void main(String[] args) {
        final Set<Instruction> instructions = FakeInstructionsGenerator.getFakeInstructions();
        final IReportGenerator reportGenerator = new ReportGenerator();

        System.out.println(reportGenerator.generateInstructionsReport(instructions));
    }
}
